var CONSTANTS = {
	baseUrl: 'https://aluuka-graph.herokuapp.com',
	stripePublicKey:
		'pk_test_51IToLLFdn8eWHl79XsOXtEowMbLpBEQnDdGx6MnzHEG14U7lbEbCddhJkXspSkJxUMOqUJCoNBPkyg0ghV1Xok5F000zCJ3K1F',
	// baseUrl: "http://localhost:5500"
};
